"""
Core engineering calculation package.
"""